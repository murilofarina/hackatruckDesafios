//
//  Aula_07_07App.swift
//  Aula 07.07
//
//  Created by Turma21-02 on 07/07/25.
//

import SwiftUI

@main
struct Aula_07_07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
