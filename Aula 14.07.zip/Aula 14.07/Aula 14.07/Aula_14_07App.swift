//
//  Aula_14_07App.swift
//  Aula 14.07
//
//  Created by Turma21-02 on 14/07/25.
//

import SwiftUI

@main
struct Aula_14_07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
