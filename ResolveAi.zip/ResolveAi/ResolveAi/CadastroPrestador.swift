//
//  ContentView.swift
//  projeto
//
//  Created by Turma02-26 on 23/07/25.
//

import SwiftUI

//struct User: Codable, Hashable {
//    let name: String
//    let isWorker: Bool
//    let occupation: String
//    let hourValue: Int
//    let bio: String
//    let photo: String
//    let state: String
//    let city: String
//}
//
//struct Cities: Codable, Hashable {
//    let id: Int
//    let nome: String
//}
//
//struct States: Codable, Hashable {
//    let id: Int
//    let sigla: String
//    let nome: String
//}

struct CadastroPrestador: View {
    
    @StateObject var stateModel = StateModel()
    @StateObject var cityModel = CityModel()
    @StateObject var userModel = UserModel()
    
    @State var occupations: [String] = ["Encanador", "Diarista"]
    
    @State var currentOccupation: String = ""
    
    @State var currentState: States? = nil
    @State var selectedCity: Cities? = nil
    @State var searchText: String = ""
    @State var photoURL: String = ""
    @State var bio: String = ""
    @State var hourValue: String = ""
    @State var name: String = ""

    @State var message: String = ""
    
    @State var createdUser: Usermapa? = nil
    @State var navigateToSuccess = false
    
    @State var text: String = ""
    
    var body: some View {
        NavigationStack {
            ScrollView(.vertical) {
                VStack(alignment: .leading) {
                    
                    Text("Criar perfil de Prestador")
                        .font(.title2)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding()
            
                    Text("Nome Completo")
                        .padding(.top, 8)
        
                    TextField("Digite seu nome completo", text: $name)
                        .frame(height: 10)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(55)
                    
                    Text("Sua foto")
                        .padding(.top, 8)
                    
                    TextField("Digite a url da imagem", text: $photoURL)
                        .frame(height: 10)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(55)
                    
                    Text("Sua localização")
                        .padding(.top, 8)
                    
                    Picker("Estado", selection: $currentState) {
                        Text("Estado").tag(nil as States?)
                        ForEach(stateModel.states, id: \.self) { state in
                            Text(state.nome).tag(Optional(state))
                        }
                    }
                    .onChange(of: currentState) { _, selectedState in
                        if let state = selectedState {
                            cityModel.fetch(id: state.id)
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
                    .accentColor(.gray)
                    .background(Color(.systemGray6))
                    .cornerRadius(55)
        
                    TextField("Digite a cidade", text: $searchText)
                        .frame(height: 10)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(55)
                    
                    if !searchText.isEmpty {
                        ForEach(cityModel.cities.filter {
                            $0.nome.lowercased().contains(searchText.lowercased())
                        }, id: \.id) { city in
                            Button(action: {
                                selectedCity = city
                                searchText = city.nome
                            }) {
                                HStack {
                                    Text(city.nome)
                                    Spacer()
                                }
                                .padding(.vertical, 4)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }

                    
                    Text("Biografia")
                        .padding(.top, 8)
                    
                    ZStack {
                        TextEditor(text: $bio)
                            .scrollContentBackground(.hidden)
                            .background(Color(.systemGray6))
                            .frame(height: 120)
                            .cornerRadius(8)
                            .foregroundColor(.blue)

                         if bio.isEmpty {
                             VStack {
                                 HStack {
                                     Text("Digite sua biografia")
                                         .foregroundStyle(.tertiary)
                                         .padding(.top, 8)
                                         .padding(.leading, 5)
                                         

                                     Spacer()
                                 }

                                 Spacer()
                             }
                         }
                     }
                    
                    Text("Serviço")
                        .padding(.top, 8)
                    
                    Picker("Tipo de serviços", selection: $currentOccupation) {
                        Text("Tipo de serviços")
                        ForEach(occupations, id: \.self) { occupation in
                            Text(occupation)
                        }
                    }
                    .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
                    .accentColor(.gray)
                    .background(Color(.systemGray6))
                    .cornerRadius(55)
                
                    TextField("Digite o valor da sua hora", text: Binding(
                        get: { hourValue },
                        set: { newValue in
                            print(newValue)
                            let semLetras = newValue.filter { !$0.isLetter }
                            hourValue = semLetras
                        }
                    ))
                    .keyboardType(.numberPad)
                    .frame(height: 10)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(55)
                    
                    Button("Criar Usuário") {
                        let newUser = Usermapa(
                            name: name,
                            isWorker: true,
                            occupation: "Developer",
                            hourValue: Int(hourValue) ?? 0,
                            bio: bio,
                            photo: photoURL,
                            state: currentState?.sigla ?? "",
                            city: selectedCity?.nome ?? ""
                        )
                        
                        userModel.createUser(user: newUser) { success in
                            DispatchQueue.main.async {
                                
                                if success {
                                    createdUser = newUser
                                    navigateToSuccess = true
                                } else {
                                    message = "Erro ao criar usuário."
                                }
                                message = success ? "Usuário criado com sucesso!" : "Falha ao criar usuário."
                            }
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
                    .foregroundStyle(.white)
                    .background(.blue)
                    .cornerRadius(55)
                    .padding(.top, 15)
                    
                    
                    Text(message)
                        .foregroundColor(message.contains("sucesso") ? .green : .red)
                    
                    NavigationLink(
                        destination: createdUser.map { SuccessView(user: $0) },
                        isActive: $navigateToSuccess
                    ) {
                        EmptyView()
                    }
                    
                }
                .onAppear() {
                    stateModel.fetch()
                }
                .onChange(of: stateModel.states) { _, newStates in
                    if let firstState = newStates.first {
                        cityModel.fetch(id: firstState.id)
                    }
                }
            }
            .padding()
        }
    }
}

#Preview {
    CadastroPrestador()
}
