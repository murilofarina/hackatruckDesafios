
import SwiftUI

struct TabViewPrestador: View {
    
    @State private var selectedTab = 0
    
    var body: some View {
        
        TabView(selection: $selectedTab) {
            HomePagePrestador()
                .tabItem {
                    Image("ic-home")
                        .renderingMode(.template)
                }
                .tag(0)
            ProfilePagePrestador()
                .tabItem {
                    Image("ic-user")
                        .renderingMode(.template)
                }
                .tag(1)
        }
    }
}

#Preview {
    TabViewPrestador()
}
