//
//  ResolveAiApp.swift
//  ResolveAi
//
//  Created by Turma21-02 on 24/07/25.
//

import SwiftUI

@main
struct ResolveAiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
