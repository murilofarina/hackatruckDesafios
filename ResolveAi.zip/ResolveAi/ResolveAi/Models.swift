struct User: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let isWorker: Bool
    let occupation: String?
    let category: String?
    let hourValue: Double?
    let bio: String?
    let photo: String?
    let state: String
    let city: String
    let latitude: Double
    let longitude: Double
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case name, isWorker, occupation, category, hourValue, bio, photo, state, city, latitude, longitude
    }
    
  
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(String.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        isWorker = try container.decode(Bool.self, forKey: .isWorker)
        occupation = try container.decodeIfPresent(String.self, forKey: .occupation)
        category = try container.decodeIfPresent(String.self, forKey: .category)
        bio = try container.decodeIfPresent(String.self, forKey: .bio)
        photo = try container.decodeIfPresent(String.self, forKey: .photo)
        state = try container.decode(String.self, forKey: .state)
        city = try container.decode(String.self, forKey: .city)
        latitude = try container.decode(Double.self, forKey: .latitude)
        longitude = try container.decode(Double.self, forKey: .longitude)

        if let hourValueString = try container.decodeIfPresent(String.self, forKey: .hourValue) {
            hourValue = Double(hourValueString)
        } else {
            hourValue = nil
        }
    }
}

struct States: Codable, Hashable, Identifiable {

    let id: Int
    let sigla: String
    let nome: String

}
    
struct Cities: Codable, Hashable, Identifiable {

    let id: Int
    let nome: String

}

struct Usermapa: Codable, Hashable {

    let name: String?

    let isWorker: Bool?

    let occupation: String?

    let hourValue: String?

    let bio: String?

    let photo: String?

    let state: String?

    let latitude: Double?

    let longitude: Double?

    let city: String?

    let category: String?

}
