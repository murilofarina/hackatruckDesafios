import SwiftUI
import MapKit

struct MapSearchView: View {
    @State var localbool = false
    @State var usuarioSelecionado: Usermapa = Usermapa(name: "", isWorker: true, occupation: "", hourValue: "", bio: "", photo: "", state: "", latitude: 22.09867900855042, longitude: 51.41509738060508, city: "", category: "")
    @State var localizacao: Usermapa? = nil


    @StateObject var viewModel = ViewModel()

    @State var posicao = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude:-14.2350, longitude: -51.9253),
            span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)
        )
    )

    var body: some View {
        NavigationStack {
            ZStack {
                Map(position: $posicao) {
                    ForEach(viewModel.usuario.filter { $0.isWorker == true &&  $0.category == localizacao?.category}, id: \.self) { local in
                        if let lat = local.latitude, let lon = local.longitude {
                            Annotation(local.name ?? "", coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon)) {
                                VStack {
                                    Image(systemName: "mappin.circle.fill")
                                        .foregroundStyle(Color("AzulMedio"))
                                        .onTapGesture {
                                            usuarioSelecionado = local
                                            localbool = true
                                        }
                                }
                            }
                        }
                    }
                }
                .ignoresSafeArea()
                .sheet(isPresented: $localbool) {
                    if usuarioSelecionado.name != "" {
                        SheetMapa(usuario: $usuarioSelecionado)
                    }
                }

                VStack {
                    
                    var categoriasUnicas: [Usermapa] {
                        var categoriasVistas = Set<String>()
                        var usuariosFiltrados: [Usermapa] = []
                        
                        for user in viewModel.usuario {
                            if user.isWorker == true,
                               let categoria = user.category,
                               !categoriasVistas.contains(categoria) {
                                
                                categoriasVistas.insert(categoria)
                                usuariosFiltrados.append(user)
                            }
                        }
                        
                        return usuariosFiltrados
                    }

                    Picker("Categoria", selection: $localizacao) {
                        ForEach(categoriasUnicas, id: \.self) { user in
                            Text(user.category ?? "").tag(Optional(user))
                        }
                    }


                    .frame(width: 250, height: 50)
                    .background(.white)
                    .cornerRadius(10)
                    .onChange(of: localizacao) { _, e in
                        if let lat = e?.latitude, let lon = e?.longitude {
                            posicao = MapCameraPosition.region(
                                MKCoordinateRegion(
                                    center: CLLocationCoordinate2D(latitude: lat, longitude: lon),
                                    span: MKCoordinateSpan(latitudeDelta: 30, longitudeDelta: 30)
                                )
                            )
                        }
                    }
                    Spacer()
                }
            }
        }
        .toolbarBackground(.hidden, for: .navigationBar)
        .onAppear() {
            viewModel.fetch()
        }
    }
}

#Preview {
    MapSearchView()
}
