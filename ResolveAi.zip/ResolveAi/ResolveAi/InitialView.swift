

import SwiftUI

struct InitialView: View {
    
    @Binding var flow: AppFlow

    var body: some View {
        
        VStack(spacing: 20) {
            Spacer()
            
            Text("ResolveAí")
                .font(.largeTitle)
                .bold()
                .padding(.top)

            Text("Conectamos quem precisa com quem resolve.")
            Text("Simples. Rápido. Perto de você.")
                .bold()
                .padding(.bottom)

            Button(action: {
                flow = .contratante
            }) {
                Text("Entrar como Contratante")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(30)
            }
            .padding(.horizontal)

            Button(action: {
                flow = .prestador
            }) {
                Text("Entrar como Prestador de Serviço")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(30)
            }
            .padding(.horizontal)

            Spacer()

            Text("Protótipo 1.0 - ResolveAí")
                .font(.footnote)
                .padding(.bottom)
        }
        .padding()
    }
}

#Preview {
    InitialView(flow: .constant(.start))
}

