
//
//  SearchPageView.swift
//  ResolveAi
//
//  Created by Turma21-02 on 24/07/25.
//

import SwiftUI

struct SearchPageView: View {
    
    @StateObject var viewModel = SearchViewModel()

    @State private var showingError = false
    
    var body: some View {
        
        ZStack{
            
            Color("AccentColor")
            
            VStack {
                
                Rectangle()
                    .foregroundColor(Color("AccentColor"))
                    .frame(width: .infinity, height: 220)
                    .ignoresSafeArea()
                
                Spacer()
                
                Rectangle()
                    .foregroundColor(Color(.white))
                    .frame(width: 383, height: 550)
                    .cornerRadius(48)
            }
            
            NavigationView {
                       VStack {
                           Picker("Estado", selection: $viewModel.selectedState) {
                               Text("Selecione um Estado").tag(nil as States?)
                               ForEach(viewModel.states, id: \.id) { state in
                                   Text(state.nome).tag(state as States?)
                               }
                           }
                           .pickerStyle(.menu)
                           .padding(.horizontal)

                           Picker("Cidade", selection: $viewModel.selectedCity) {
                               Text("Selecione uma Cidade").tag(nil as Cities?)
                               ForEach(viewModel.cities, id: \.id) { city in
                                   Text(city.nome).tag(city as Cities?)
                               }
                           }
                           .pickerStyle(.menu)
                           .padding(.horizontal)
                           .disabled(viewModel.selectedState == nil)

                           HStack {
                               Picker("Categoria", selection: $viewModel.selectedCategory) {
                                   ForEach(viewModel.categories, id: \.self) { category in
                                       Text(category).tag(category)
                                   }
                               }
                               .pickerStyle(.menu)

                               Menu {
                                   Picker("Faixa de Preço", selection: $viewModel.selectedPriceRange) {
                                       ForEach(SearchViewModel.PriceRange.allCases) { range in
                                           Text(range.rawValue).tag(range)
                                       }
                                   }
                               } label: {
                                   HStack {
                                       Text(viewModel.selectedPriceRange.rawValue)
                                       Image(systemName: "chevron.down")
                                   }
                                   .font(.body)
                                   .foregroundColor(.accentColor)
                               }
                           }
                           .padding(.horizontal)

                           Divider()

                           if viewModel.isLoading {
                               ProgressView()
                               Spacer()
                           } else if viewModel.filteredUsers.isEmpty {
                               Text("Nenhum prestador encontrado com esses critérios.")
                                   .foregroundColor(.gray)
                                   .padding(.top, 50)
                               Spacer()
                           } else {
                               List(viewModel.filteredUsers) { user in
                                   VStack(alignment: .leading) {
                                       Text(user.name)
                                           .font(.headline)
                                       Text(user.occupation ?? "Profissional")
                                           .font(.subheadline)
                                           .foregroundColor(.secondary)
                                   }
                               }
                           }
                       }
                       .padding(.top, 80)
                       
                       .alert(isPresented: $showingError) {
                           Alert(title: Text("Erro"), message: Text(viewModel.errorMessage ?? "Ocorreu um erro."), dismissButton: .default(Text("OK")))
                       }
                       .onReceive(viewModel.$errorMessage) { msg in
                           showingError = (msg != nil)
                       }
                   }
            
        }
    }
}

#Preview {
    SearchPageView()
}



////
////  SearchPageView.swift
////  ResolveAi
////
////  Created by Turma21-02 on 24/07/25.
////
//
//import SwiftUI
//
//struct SearchPageView: View {
//    
//    @StateObject var viewModel = SearchViewModel()
//
//    @State private var showingError = false
//    
//    var body: some View {
//        
//        ZStack{
//            
//            Color("AccentColor").ignoresSafeArea()
//            
//            VStack {
//                
//                Rectangle()
//                    .foregroundColor(Color("AccentColor"))
//                    .frame(width: .infinity, height: 350)
//                    .ignoresSafeArea()
//                
//                Spacer()
//                
//                Rectangle()
//                    .foregroundColor(Color(.white))
//                    .frame(width: 393, height: 700)
//                    .cornerRadius(48)
//                    
//                    
//            }
//            
//            
//                       VStack {
//                           VStack(spacing: 12) {
//                               
//                               // Linha de cima: Estado + Cidade
//                               HStack(spacing: 8) {
//                                   Picker("Estado", selection: $viewModel.selectedState) {
//                                       Text("Selecione um Estado").tag(nil as States?)
//                                       ForEach(viewModel.states, id: \.id) {
//                                           Text($0.nome).tag($0 as States?)
//                                       }
//                                   }
//                                   .pickerStyle(.menu)
//                                   .frame(maxWidth: .infinity)
//                                   .padding(.vertical, 6)
//                                   .padding(.horizontal, 12)
//                                   .background(Color.white)
//                                   .cornerRadius(20)
//                                   .tint(.accentColor)
//
//                                   Picker("Cidade", selection: $viewModel.selectedCity) {
//                                       Text("Selecione uma Cidade").tag(nil as Cities?)
//                                       ForEach(viewModel.cities, id: \.id) {
//                                           Text($0.nome).tag($0 as Cities?)
//                                       }
//                                   }
//                                   .pickerStyle(.menu)
//                                   .frame(maxWidth: .infinity)
//                                   .padding(.vertical, 6)
//                                   .padding(.horizontal, 12)
//                                   .background(Color.white)
//                                   .cornerRadius(20)
//                                   .tint(.accentColor)
//                               }.padding(.horizontal, 8)
//
//                               // Linha de baixo: Categoria + Faixa de Preço
//                               HStack(spacing: 8) {
//                                   Picker("Categoria", selection: $viewModel.selectedCategory) {
//                                       ForEach(viewModel.categories, id: \.self) {
//                                           Text($0).tag($0)
//                                       }
//                                   }
//                                   .pickerStyle(.menu)
//                                   .frame(maxWidth: .infinity)
//                                   .padding(.vertical, 6)
//                                   .padding(.horizontal, 12)
//                                   .background(Color.white)
//                                   .cornerRadius(20)
//                                   .tint(.accentColor)
//
//                                   Picker("Faixa de Preço", selection: $viewModel.selectedPriceRange) {
//                                       ForEach(SearchViewModel.PriceRange.allCases) {
//                                           Text($0.rawValue).tag($0)
//                                       }
//                                   }
//                                   .pickerStyle(.menu)
//                                   .frame(maxWidth: .infinity)
//                                   .padding(.vertical, 6)
//                                   .padding(.horizontal, 12)
//                                   .background(Color.white)
//                                   .cornerRadius(20)
//                                   .tint(.accentColor)
//                               }.padding(.horizontal, 8)
//                           }
//                           .padding(.horizontal, 12)
//
//
//
//                           if viewModel.isLoading {
//                               ProgressView()
//                               Spacer()
//                           } else if viewModel.filteredUsers.isEmpty {
//                               Text("Nenhum prestador encontrado com esses critérios.")
//                                   .foregroundColor(.gray)
//                                   .padding(.top, 50)
//                               Spacer()
//                           } else {
//                               ScrollView {
//                                   VStack(spacing: 16) {
//                                       ForEach(viewModel.filteredUsers, id: \.id) { user in
//                                           HStack(spacing: 12) {
//                                               AsyncImage(url: URL(string: user.photo ?? "")) { phase in
//                                                   if let image = phase.image {
//                                                       image
//                                                           .resizable()
//                                                           .aspectRatio(contentMode: .fill)
//                                                           .frame(width: 60, height: 60)
//                                                           .clipShape(Circle())
//                                                   } else if phase.error != nil {
//                                                       Image(systemName: "person.crop.circle.badge.exclam")
//                                                           .resizable()
//                                                           .frame(width: 48, height: 48)
//                                                           .foregroundColor(.gray)
//                                                   } else {
//                                                       ProgressView()
//                                                           .frame(width: 48, height: 48)
//                                                   }
//                                               }
//
//                                               VStack(alignment: .leading, spacing: 13) {
//                                                   Text(user.name)
//                                                       .font(.headline)
//                                                       .foregroundColor(.primary)
//
//                                                   Text(user.occupation ?? "Profissional")
//                                                       .font(.subheadline)
//                                                       .foregroundColor(.secondary)
//
//                                                   Text("\(user.city), \(user.state)")
//                                                       .font(.caption)
//                                                       .foregroundColor(.gray)
//                                               }
//
//                                               Spacer()
//                                           }
//                                           .padding()
//                                           .background(Color.cinz)
//                                           .cornerRadius(25)
//                                           .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
//                                       }
//                                   }
//                                   .padding(.horizontal)
//                               }.padding(.top, 45)
//                                   .padding(.horizontal, 8)
//
//
//                           }
//                       }
//                       .padding(.top, 218)
//                       
//                       .alert(isPresented: $showingError) {
//                           Alert(title: Text("Erro"), message: Text(viewModel.errorMessage ?? "Ocorreu um erro."), dismissButton: .default(Text("OK")))
//                       }
//                       .onReceive(viewModel.$errorMessage) { msg in
//                           showingError = (msg != nil)
//                       }
//                   }
//            
//        }
//}
//
//#Preview {
//    SearchPageView()
//}
