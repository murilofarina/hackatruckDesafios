import SwiftUI

struct SinglePrestador: View {
    
    var user = User(
        name: "fasdf",
        isWorker: true,
        occupation: "Developer",
        hourValue: 50,
        bio: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
        photo: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQw3iIiDJQW4HYJk2osK19O3RQ4Hs4MDSF8PQ&s",
        state: "SP",
        city: "Presidente Prudente"
    )
    @State private var showingAlert = false
        @State private var name = ""
    
    @State private var showPopover = false
    
    func submit() {
            print("You entered \(name)")
        }
    
    @State private var mostrarPopup = false

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            VStack(spacing: 16) {
                Button("Abrir Popup") {
                    mostrarPopup = true
                }
                AsyncImage(url: URL(string: user.photo ?? "")) { image in
                    image
                        .resizable()
                        .scaledToFill()
                } placeholder: {
                    ProgressView()
                }
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                
                Text(user.name ?? "Nome do Prestador")
                    .font(.title)
                    .bold()
                
                HStack {
                    Image(systemName: "mappin.circle")
                    Text("\(user.city ?? ""), \(user.state ?? "")")
                        .foregroundColor(.gray)
                }
                
                HStack {
                    VStack {
                        Image(systemName: "briefcase")
                        Text(user.occupation ?? "Tipo de Serviço")
                    }
                    .frame(width: 120, height: 100)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    
                    VStack {
                        Image(systemName: "dollarsign.circle")
                    }
                    .frame(width: 120, height: 100)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                }
                
                Text(user.bio ?? "Sem biografia disponível.")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                
                Button("Contratar") {
                    showingAlert.toggle()
                }
                .alert("Confirmar Contrataçao", isPresented: $showingAlert) {
                    HStack {
                        Text("Prestador:")
                            .bold()
                            .underline()
                        Text("Nome do Prestador")
                    }
                    
                    TextField("Enter your name", text: $name)
                    Button("OK", action: submit)
                } message: {
                    Text("Xcode will print whatever you type.")
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .center)
                .foregroundStyle(.white)
                .background(.blue)
                .cornerRadius(55)
                .padding(.top, 15)
                
                Spacer()
            }
            .padding(30)
            
            
            if mostrarPopup {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                
                ContratoView(user: user)
                    .background(Color.white)
                    .cornerRadius(25)
                    .padding(30)
                    .shadow(radius: 10)
                    .frame(width: .infinity)
            }
        }
    }
}

#Preview {
    SinglePrestador()
}
