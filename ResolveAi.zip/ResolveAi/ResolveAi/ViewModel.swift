import Foundation
import Combine

 

class ViewModel: ObservableObject{

    @Published var usuario: [Usermapa] = []

func fetch(){

guard let url = URL(string: "http://192.168.128.45:1880/getProject") else {

return

}

 

let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in

guard let data = data, error == nil else{

return

}

do {

 

let parsed = try JSONDecoder().decode([Usermapa].self, from: data)

DispatchQueue.main.async {

self?.usuario = parsed

}

}

catch {

print(error)

 

}

 

}

 

task.resume()

}

 

 

}

@MainActor
class SearchViewModel: ObservableObject {

    @Published var states: [States] = []
    @Published var cities: [Cities] = []
    @Published var filteredUsers: [User] = []

    @Published var selectedState: States? {
        didSet { Task { await stateChanged() } }
    }
    @Published var selectedCity: Cities? {
        didSet { applyFilters() }
    }
    @Published var selectedCategory: String = "Todas as Categorias" {
        didSet { applyFilters() }
    }
    @Published var selectedPriceRange: PriceRange = .all {
        didSet { applyFilters() }
    }
    @Published var searchCityText: String = "" {
        didSet { applyFilters() }
    }

    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil

    enum PriceRange: String, CaseIterable, Identifiable {
        case all = "Qualquer Preço"
        case upTo50 = "Até R$50/h"
        case between50and100 = "R$50 - R$100/h"
        case over100 = "Acima de R$100/h"
        var id: String { self.rawValue }
    }

    let categories = ["Todas as Categorias", "Elétrica", "Encanamentos", "Casa", "Pequenos Reparos"]

    private var cancellables = Set<AnyCancellable>()
    private var allUsers: [User] = [] {
        didSet { applyFilters() }
    }
    private var citiesCache: [Int: [Cities]] = [:]

    init() {
        print("--- DEBUG: ViewModel iniciado. ---")
        Task {
            await fetchStates()
            await fetchAllUsers()
        }
    }

    private func applyFilters() {
        print("--- DEBUG: Aplicando filtros... ---")

        var results = allUsers.filter { $0.isWorker }

        if let state = selectedState {
            results = results.filter {
                $0.state.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == state.sigla.lowercased()
            }
        }

        if !searchCityText.isEmpty {
            results = results.filter {
                $0.city.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().contains(searchCityText.lowercased())
            }
        } else if let city = selectedCity {
            results = results.filter {
                $0.city.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == city.nome.lowercased()
            }
        }

        if selectedCategory != "Todas as Categorias" {
            results = results.filter {
                ($0.category ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == selectedCategory.lowercased()
            }
        }

        switch selectedPriceRange {
        case .upTo50:
            results = results.filter {
                guard let value = $0.hourValue else { return false }
                return value <= 50
            }
        case .between50and100:
            results = results.filter {
                guard let value = $0.hourValue else { return false }
                return value > 50 && value <= 100
            }
        case .over100:
            results = results.filter {
                guard let value = $0.hourValue else { return false }
                return value > 100
            }
        case .all:
            break
        }

        filteredUsers = results
        print("--- DEBUG: Encontrados \(results.count) usuários filtrados.")
    }

    func fetchAllUsers() async {
        print("--- DEBUG: Iniciando busca de TODOS os usuários... ---")
        isLoading = true
        defer { isLoading = false }
        guard let url = URL(string: "http://192.168.128.45:1880/getProject") else {
            errorMessage = "URL de usuários inválida."
            return
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let parsed = try decoder.decode([User].self, from: data)
            print("--- DEBUG: Usuários decodificados: \(parsed.count) ---")
            allUsers = parsed
        } catch {
            errorMessage = "Falha ao buscar usuários: \(error.localizedDescription)"
            print("--- DEBUG: Erro: \(error) ---")
        }
    }

    func fetchStates() async {
        print("--- DEBUG: Buscando estados IBGE... ---")
        isLoading = true
        defer { isLoading = false }
        guard let url = URL(string: "https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome") else {
            errorMessage = "URL de estados inválida."
            return
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let parsed = try decoder.decode([States].self, from: data)
            states = parsed
        } catch {
            errorMessage = "Falha ao buscar estados: \(error.localizedDescription)"
            print("--- DEBUG: Erro estados: \(error) ---")
        }
    }

    private func stateChanged() async {
        cities = []
        selectedCity = nil
        guard let state = selectedState else { return }
        if let cached = citiesCache[state.id] {
            cities = cached
        } else {
            await fetchCities(forStateID: state.id)
        }
    }

    func fetchCities(forStateID stateID: Int) async {
        print("--- DEBUG: Buscando cidades para estado \(stateID) ---")
        isLoading = true
        defer { isLoading = false }
        guard let url = URL(string: "https://servicodados.ibge.gov.br/api/v1/localidades/estados/\(stateID)/municipios?orderBy=nome") else {
            errorMessage = "URL de cidades inválida."
            return
        }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let parsed = try decoder.decode([Cities].self, from: data)
            print("--- DEBUG: Cidades encontradas: \(parsed.count) ---")
            citiesCache[stateID] = parsed
            cities = parsed
        } catch {
            errorMessage = "Falha ao buscar cidades: \(error.localizedDescription)"
            print("--- DEBUG: Erro cidades: \(error) ---")
        }
    }
}
