//
//  ProfilePageView.swift
//  ResolveAi
//
//  Created by Turma21-02 on 24/07/25.
//

import SwiftUI

struct ProfilePageView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ProfilePageView()
}
