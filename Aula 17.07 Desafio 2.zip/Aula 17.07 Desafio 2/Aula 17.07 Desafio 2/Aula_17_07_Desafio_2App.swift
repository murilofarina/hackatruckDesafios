//
//  Aula_17_07_Desafio_2App.swift
//  Aula 17.07 Desafio 2
//
//  Created by Turma21-02 on 17/07/25.
//

import SwiftUI

@main
struct Aula_17_07_Desafio_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
