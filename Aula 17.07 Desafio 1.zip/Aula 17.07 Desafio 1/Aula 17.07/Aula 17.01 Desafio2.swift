//
//  Aula 17.01 Desafio2.swift
//  Aula 17.07
//
//  Created by Turma21-02 on 17/07/25.
//

import SwiftUI

struct Aula_17_01_Desafio2: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Aula_17_01_Desafio2()
}
