//
//  Aula_16_07App.swift
//  Aula 16.07
//
//  Created by Turma21-02 on 16/07/25.
//

import SwiftUI

@main
struct Aula_21_07__umidadeApiNodeRedApp: App {
    
    var body: some Scene {
        
        WindowGroup {
            ContentView()
        }
    }
}
