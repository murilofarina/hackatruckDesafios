//
//  ContentView.swift
//  Aula 08.07
//
//  Created by Turma21-02 on 08/07/25.
//

import SwiftUI
import MapKit

struct Location: Hashable {
    let nome: String
    let foto: String
    let descricao: String
    let latitude: Double
    let longitude: Double
}

struct Loc: Identifiable {
    let id = UUID()
    let nome: String
    let coordenada: CLLocationCoordinate2D
}

var arrayLocation = [Location(nome: "Taj Mahal", foto: "https://www.foxworldtravel.com/wp-content/uploads/2023/03/Taj-Mahal-scaled-1.jpeg",
    descricao: "O Taj Mahal é um famoso mausoléu de mármore branco localizado em Agra, na Índia. Foi construído pelo imperador Mughal Shah Jahan em memória de sua esposa favorita, Mumtaz Mahal, e é considerado uma obra-prima da arquitetura Mughal, combinando elementos das arquiteturas islâmica, persa e indiana", latitude: 27.1750, longitude: 78.0422),
                     Location(nome: "Cristo Redentor", foto: "https://grupocataratas.com/wp-content/uploads/2023/04/Copia-de-Copia-de-DJI_0031-scaled.jpg",
                              descricao: "O Cristo Redentor é uma estátua icônica de Jesus Cristo localizada no topo do morro do Corcovado, no Rio de Janeiro, Brasil. É um dos principais símbolos do cristianismo e um marco cultural do Brasil, conhecido mundialmente. A estátua, com seus 38 metros de altura, oferece vistas panorâmicas deslumbrantes da cidade e é considerada uma das Sete Maravilhas do Mundo Moderno", latitude: -22.5735, longitude: -43.1234)]

struct ContentView: View {
    
    @State var localBool = false
    
    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 20.1750, longitude: 30.0422),
            span: MKCoordinateSpan(latitudeDelta: 50, longitudeDelta: 50))
        )
    @State var arrayPicker = Location(nome: "Taj Mahal", foto: "https://www.foxworldtravel.com/wp-content/uploads/2023/03/Taj-Mahal-scaled-1.jpeg",
                                      descricao: "O Taj Mahal é um famoso mausoléu de mármore branco localizado em Agra, na Índia. Foi construído pelo imperador Mughal Shah Jahan em memória de sua esposa favorita, Mumtaz Mahal, e é considerado uma obra-prima da arquitetura Mughal, combinando elementos das arquiteturas islâmica, persa e indiana", latitude: 27.1750, longitude: 78.0422)
    var body: some View {
        ZStack{
            VStack{
                Map(position: $position){
                    ForEach(arrayLocation, id: \.self) { loc in
                        Annotation(loc.nome, coordinate: CLLocationCoordinate2D(latitude: loc.latitude, longitude: loc.longitude))
                        {
                            VStack{
                                Image(systemName: "mappin.circle.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30)
                            }.onTapGesture {
                                localBool = true
                                
                            }
                        }
                    }
                }  .ignoresSafeArea()
            } //sheetview
            .sheet(isPresented: $localBool) {
            } content: {
                VStack {
                    AsyncImage(url: URL(string: arrayPicker.foto)) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .scaledToFit()
                    .frame(width: 300)
                    .cornerRadius(16)
                    .padding(30)
                }
                VStack {
                    Text(arrayPicker.nome)
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                }
                VStack {
                    Text(arrayPicker.descricao)
                        .frame(width: 250, height: 300)
                        .padding(30)
                        .background(.color)
                        .cornerRadius(16)
                }
            }
            
            VStack{
                Picker("Selecione o local desejado", selection: $arrayPicker) {
                    ForEach(arrayLocation, id: \.self) { i in
                        Text(i.nome)
                    }
                } .frame(width: 250, height: 50)
                .background(.white)
                .cornerRadius(16)
                .tint(.black)
                
                //.onchange{}
                .onChange(of: arrayPicker) { i in
                            position = MapCameraPosition.region(
                                MKCoordinateRegion(
                                    center: CLLocationCoordinate2D(latitude: i.latitude, longitude: i.longitude),
                                    span: MKCoordinateSpan(latitudeDelta: 50, longitudeDelta: 50))
                                )
                }
                Spacer()
            }
            VStack{
                Spacer()
                Text("Maravilhas do Mundo Moderno")
                    .frame(width: 300, height: 50)
                    .background(.white)
                    .cornerRadius(16)
            }
        }
        
    }
}

#Preview {
    ContentView()
}
