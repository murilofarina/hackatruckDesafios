//
//  Aula_08_07App.swift
//  Aula 08.07
//
//  Created by Turma21-02 on 08/07/25.
//

import SwiftUI

@main
struct Aula_08_07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
